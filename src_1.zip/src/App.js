
import Registration  from './components/registration';
import './App.css';

function App() {
  return (
    <div className="App">

      {/* registation page/index page */}
        <Registration/>
    </div>
  );
}

export default App;
