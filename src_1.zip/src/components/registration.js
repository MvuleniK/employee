import React from 'react';
import '../components/registration.css';

function registration() {
  return (
    <div>
        <form>
            <h3>Employee full name</h3>
            <input type="text" name="full-name" class="input" placeholder="Enter in your fullname" className="regFirstName"></input>
            <h3>Email address</h3>  
            <input type="text" name="user-mail" class="input" placeholder="Enter in your email" className="regMail"></input>
            <h3>Phone number </h3>
            <input type="text" name="phone-number" class="input" placeholder="Enter in your phone number" className="regPhonenumber"></input>
            <h3> Password </h3>
            <input type="password" name="password" class="input" placeholder="Enter in your password" className="regPassword"></input>
            <h3> Re-enter password </h3>
            <input type="confirmpassword" name="confirmpassword" class="input" placeholder="Re-enter your password " className ="regPasswordconfirm"></input>
        </form>
        

            <h3>Upload profile image</h3>
            <input type="file" accept="image/png ,image/jpg" className="imageInput"> </input>
            <img src="" id="userImage1" width="100" height="100"></img>
            <p>
                By continuing, you agree to Amazon's <a href="#">Conditions of Use</a> and <a href="#">Privacy Notice</a>
            </p>
            <button class="register_registerButton" onclick="registration()"> Continue </button>    
    </div>
  )
}

export default registration







function registration() {
    /////////////////////Registration  Variables ///////////////////////////////////////////////////////////
    var firstname = document.getElementById("regFirstName").value;
    var email = document.getElementById("regMail").value;
    var phone = document.getElementById("regPhonenumber").value;
    var pwd = document.getElementById("regPassword").value;
    var cpwd = document.getElementById("regPasswordconfirm").value;

    //console.log(firstname + ", " + email + ", " + pwd + ", " + cpwd);



    //conditions and parameters of the input data ///////////////////////////////////
    var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
    var letters = /^[A-Za-z]+$/;
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var numFilter = /^\d{10}$/;

    //conditions and parameters of the input data ///////////////////////////////////

    if (firstname == '') {
        alert('Please enter your name')
    } else if (!letters.test(firstname)) {
        alert('Name field requires only alphabet characters')
    } else if (email == '') {
        alert("Please enter your email")
    } else if (!filter.test(email)) {
        alert('Invalid email');
    } else if (phone == "") {
        window.alert("Please enter your telephone number");
    } else if (!numFilter.test(phone)) {
        alert('invalid phone number, only numeric digits')
    } else if (pwd == '') {
        alert('Please enter Password');
    } else if (cpwd == '') {
        alert('Enter Confirm Password');
    } else if (!pwd_expression.test(pwd)) {
        alert('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
    } else if (pwd != cpwd) {
        alert('Password not Matched');
    } else if (document.getElementById("regPassword").value.length < 6) {
        alert('Password minimum length is 6');
    } else if (document.getElementById("regPassword").value.length > 12) {
        alert('Password max length is 12');
    } else {
        ////Store Information To Localstorage////
        //var firstname = document.getElementById("regFirstName").value;
        //var email = document.getElementById("regMail").value;
        //var pwd = document.getElementById("regPassword").value;
        //var cpwd = document.getElementById("regPasswordconfirm").value;
        localStorage.setItem('regFirstName', firstname);
        localStorage.setItem('regMail', email);
        localStorage.setItem('regPasswordconfirm', cpwd);
        ////////redirect user to login form                                          
        alert('Your account has been created , Redirecting you to Login Website');
        // Redirecting to other page or webste code. 
        window.location.href = "./login.html";
    }



}

function changeName() {
    const name_Element = document.getElementById("regFirstName");
    name_Element.innerHTML = localStorage.regFirstName;
}